cd ..
make
cd svm_struct/
gcc -shared -Wl,-soname,lib_svm_rank_classify_single.so -o lib_svm_rank_classify_single.so  svm_struct_classify_jad_2.o svm_struct_common.o ../svm_struct_api.o ../svm_light/svm_common.o
gcc -shared -Wl,-soname,lib_svm_rank_classify_single_mem.so -o lib_svm_rank_classify_single_mem.so  svm_struct_classify_jad_3.o svm_struct_common.o ../svm_struct_api.o ../svm_light/svm_common.o
python ptest.py
