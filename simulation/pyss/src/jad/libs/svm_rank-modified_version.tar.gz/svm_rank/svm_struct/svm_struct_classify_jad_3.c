/***********************************************************************/
/*                                                                     */
/*   svm_struct_classify.c                                             */
/*                                                                     */
/*   Classification module of SVM-struct.                              */
/*                                                                     */
/*   Author: Thorsten Joachims                                         */
/*   Date: 03.07.04                                                    */
/*                                                                     */
/*   Copyright (c) 2004  Thorsten Joachims - All rights reserved       */
/*                                                                     */
/*   This software is available for non-commercial use only. It must   */
/*   not be modified and distributed without prior permission of the   */
/*   author. The author is not responsible for implications from the   */
/*   use of this software.                                             */
/*                                                                     */
/************************************************************************/

#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif
#include "../svm_light/svm_common.h"
#ifdef __cplusplus
}
#endif
#include "../svm_struct_api.h"
#include "svm_struct_common.h"


STRUCTMODEL model;
STRUCT_LEARN_PARM sparm;


int main (int argc, char* argv[]) {return 0;}

/* int C = 0; void inc() {printf("%d\n", C++);} */


void update_model(char* model_file)
{
    model = read_struct_model(model_file, &sparm);

    if (model.svm_model->kernel_parm.kernel_type == LINEAR) { /* linear kernel */
        /* compute weight vector */
        add_weight_vector_to_linear_model(model.svm_model);
        model.w = model.svm_model->lin_weights;
    }
}

char* rank(char* test_example)
{
    sparm.custom_argc=0;

    SAMPLE testsample = read_struct_examples_mem(test_example, &sparm);

    char* buffer = NULL;
    size_t bufferSize = 0;
    FILE* myStream = open_memstream(&buffer, &bufferSize);

    LABEL y = classify_struct_example(testsample.examples[0].x, &model, &sparm);

    write_label(myStream, y);

    free_label(y);
    free_struct_sample(testsample);

    // free_struct_model(model);

    fclose(myStream);

    return buffer;
}

void print_help(void)
{
    printf("### Developer version, modified by me (Jad)\n");
}
